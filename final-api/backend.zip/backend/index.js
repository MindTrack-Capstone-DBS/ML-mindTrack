import express from 'express';
import axios from 'axios';

const app = express();
app.use(express.json());

// Route to check connection with FastAPI
app.post('/predict', async (req, res) => {
  try {
    const response = await axios.post('http://localhost:8000/predict', {
      text: req.body.text || "test message"
    });

    res.json({
      message: "Berhasil terhubung ke FastAPI!",
      hasil_prediksi: response.data
    });
  } catch (error) {
    console.error("Gagal komunikasi dengan FastAPI:", error.message);
    res.status(500).json({ error: "Gagal terhubung ke FastAPI" });
  }
});

app.listen(3000, () => {
  console.log("Express.js backend berjalan di http://localhost:3000");
});
